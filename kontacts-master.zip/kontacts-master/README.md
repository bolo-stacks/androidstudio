# Kontacts

A contacts showcase app for a workshop about Kotlin for Android that was aired online. This is the link to the video (in Spanish):

[Kotlin for Android workshop](https://www.youtube.com/watch?v=04CXn85jg8M)

## How to use
In Android Studio:

1. Install Kotlin plugin
2. Install Kotlin Android Extensions plugin
3. Enjoy

## License

    Copyright 2015 Antonio Leiva

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
