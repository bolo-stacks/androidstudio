package com.antonioleiva.kontacts

data class Contact(val name: String, val imageUrl: String)